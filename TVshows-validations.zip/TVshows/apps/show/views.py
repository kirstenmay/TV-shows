from django.shortcuts import render, redirect
from .models import Show
from django.contrib import messages

def shows(request):
    context = {
        'shows': Show.objects.all()
    }
    return render(request, 'show/shows.html', context)

def database_add(request):
    errors = Show.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/shows/new")
    else:
        new_show = Show.objects.create(title = request.POST.get('title'), network = request.POST.get('network'), release_date = request.POST.get('release_date'), desc = request.POST.get('description'))
        show_id = new_show.id
        messages.success(request, "Show successfully added!")
        return redirect(f"/shows/{show_id}")

def add_show(request):
    return render(request, 'show/add_show.html')

def display_show(request, show_id):
    context = {
        'show': Show.objects.get(id=show_id)
    }
    return render(request, 'show/display_show.html', context)

def edit_show(request, show_id):
    context = {
        'show': Show.objects.get(id=show_id)
    }
    return render(request, 'show/edit_show.html', context)

def database_edit(request):
    errors = Show.objects.basic_validator(request.POST)
    show = Show.objects.get(id = request.POST.get('show_id'))
    show_id = show.id
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f"/shows/{show_id}/edit")
    else:
        show.title = request.POST.get('title')
        show.network = request.POST.get('network')
        show.release_date = request.POST.get('release_date')
        show.desc = request.POST.get('description')
        show.save()
        return display_show(request, show_id)

def delete(request, show_id):
    show = Show.objects.get(id = show_id)
    show.delete()
    return redirect("/shows")