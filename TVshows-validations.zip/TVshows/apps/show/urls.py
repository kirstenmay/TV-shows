from django.conf.urls import url
from . import views
                    
urlpatterns = [
    url(r'^/(?P<show_id>\d+)/delete$', views.delete),
    url(r'^/(?P<show_id>\d+)/edit$', views.edit_show),
    url(r'^/(?P<show_id>\d+)$', views.display_show),
    url(r'^/database_edit', views.database_edit),
    url(r'^/database_add', views.database_add),
    url(r'^/new', views.add_show),
    url(r'^', views.shows),
]
